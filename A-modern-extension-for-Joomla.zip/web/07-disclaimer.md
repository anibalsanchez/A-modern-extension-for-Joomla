## Disclaimer <!-- .slide: data-background-repeat="no-repeat" data-background-image="images/00-home/jab18_logo.png" data-background-size="auto auto" data-background-position="95% 5%" -->

My opinions are my own


## Not About J4 <!-- .slide: data-background-image="images/05-who/joomla_logo.png" data-background-size="auto auto" data-background-position="100% 5%" -->

We are not going to talk about:

- Joomla 4
- Bootstrap 4
- jQuery 3
- Code reorganization / Namespaces
- The new Site/Administrator template
