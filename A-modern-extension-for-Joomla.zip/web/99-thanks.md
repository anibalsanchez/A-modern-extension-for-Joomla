## One Opportunity

There is no modern CMS for this era ... yet.


## One Opportunity

<!-- .element: class="fragment" --> <i class="far fa-check-square"></i> Provide innovative services

<!-- .element: class="fragment" --> <i class="far fa-check-square"></i> Support your clients

<!-- .element: class="fragment" --> <i class="far fa-check-square"></i> Solve challenges

<!-- .element: class="fragment" --> <i class="far fa-check-square"></i> Reach new markets

<!-- .element: class="fragment" --> <i class="far fa-check-square"></i> Find your strength

<!-- .element: class="fragment" --> <i class="far fa-check-square"></i> Learn something new every day


## Conclusion

The path is the goal.

![The path is the goal](images/99-thanks/light-863150_640.jpg)<!-- .element: style="width: 40%" -->


## Feedback & Questions

Thank you for your attention!


## Mastermind

![The Spanish Podcast about Joomla](images/99-thanks/spamissexy.jpg)<!-- .element: style="width: 40%" -->

The Spanish Podcast about Joomla

<!-- .element: class="small" --><https://mastermindjoomla.com/> #spamisexy
